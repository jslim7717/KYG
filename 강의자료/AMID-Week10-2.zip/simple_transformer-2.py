import torch
import torch.nn as nn

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_ch=3, emb_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_ch, emb_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        x = self.proj(x)  
        print("After projection shaep:", x.shape)
        x = x.flatten(2).transpose(1, 2)  
        print("After flatten shape:", x.shape)
        return x

class AddPositionEmbedding(nn.Module):
    def __init__(self, num_patches, emb_dim):
        super().__init__()
        self.cls_token = nn.Parameter(torch.zeros(1, 1, emb_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, emb_dim))

    def forward(self, x):
        B = x.shape[0]
        cls = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls, x], dim=1)  
        x = x + self.pos_embed
        return x

class MiniViT(nn.Module):
    def __init__(self, img_size=224, patch_size=16, emb_dim=768, num_heads=8):
        super().__init__()
        self.patch = PatchEmbedding(img_size, patch_size, 3, emb_dim)
        self.pos = AddPositionEmbedding((img_size // patch_size) ** 2, emb_dim)

    def forward(self, x):
        print("Input IMAGE data shape:", x.shape)
        x = self.patch(x)
        print("After PatchEmbedding shape:", x.shape)  # [B, 196, D]
        x = self.pos(x)
        print("After PosEmbedding + CLS shape:", x.shape)  # [B, 197, D]
        return x

model = MiniViT()
dummy = torch.randn(1, 3, 224, 224)
output = model(dummy)


