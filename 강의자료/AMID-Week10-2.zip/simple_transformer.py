import torch
import torch.nn as nn

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_ch=3, emb_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_ch, emb_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        x = self.proj(x)  
        print("After projection shaep:", x.shape)
        x = x.flatten(2).transpose(1, 2)  
        print("After flatten shape:", x.shape)
        return x

class MiniViT(nn.Module):
    def __init__(self, img_size=224, patch_size=16, emb_dim=768, num_heads=8):
        super().__init__()
        self.patch = PatchEmbedding(img_size, patch_size, 3, emb_dim)

    def forward(self, x):
        print("Input IMAGE data shape:", x.shape)
        x = self.patch(x)
        print("After PatchEmbedding shape:", x.shape)  # [B, 196, D]

        return x

model = MiniViT()
dummy = torch.randn(1, 3, 224, 224)
output = model(dummy)


